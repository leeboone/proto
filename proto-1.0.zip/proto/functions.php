<?php 
/**
 * @package Proto
 */


require("functions/admin.php");
require("functions/filters.php");
require("functions/settings.php");
require("functions/utilities.php");
require("functions/slides.php");
require("functions/widgets.php");

















?>